export const ROUTES = {
    ERROR: "/error",
    NOTFOUND: "/notfound",
};
