export const ROUTES = {
    MUI_DEMO: "/mui",
    MUI_LAZY_DEMO: "/muilazy",
};
