export const ROUTES = {
    CUSTOMERS: "/customers",
    CUSTOMER: "/customers/:id",
    CUSTOMER_CREATE: "/customer/create"
}