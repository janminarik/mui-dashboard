export interface CustomThemeAttributes {
    navigationPanelWidth?: number;
    closeNavigationPanelWidth?: number;
    settingsPanelWidth?: number;
}